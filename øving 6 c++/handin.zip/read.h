#pragma once

void readWordToFile();
void readLineNumber();