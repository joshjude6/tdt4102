#pragma once

void characterCount();